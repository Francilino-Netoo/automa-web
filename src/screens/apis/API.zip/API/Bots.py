import subprocess
import time

scripts = ["./Bot/bacbo.py"]

processes = {}

def start_process(script):
    
    return subprocess.Popen(["python", script])

for script in scripts:
    processes[script] = start_process(script)

while True:
    for script, process in processes.items():
        
        if process.poll() is not None: 
            print(f"{script} parou. Reiniciando...")
            processes[script] = start_process(script)  

    time.sleep(5)  