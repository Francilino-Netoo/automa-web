import os
import subprocess
import sys

def create_virtualenv():
    print("Criando ambiente virtual...")
    if os.name == "nt":
        subprocess.run([sys.executable, "-m", "venv", ".venv"], check=True)
    else:
        subprocess.run([sys.executable, "-m", "venv", "venv"], check=True)
    print("Ambiente virtual criado.")


venv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".venv" if os.name == "nt" else "venv")
if not os.path.exists(venv_path):
    create_virtualenv()


# Após isso ative o ambiente virtual usando esse comando no terminal -> .venv\Scripts\Activate

# Depois disso é so instalar os requeriments.txt -> pip install -r requirements.txt