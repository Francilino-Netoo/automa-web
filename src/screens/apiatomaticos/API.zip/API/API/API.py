import json
import os
import sys
import socketio

sio = socketio.Client()

@sio.event
def connect():
    print("API Ligada")

@sio.event
def disconnect():
    print("API Desligada")
    sys.exit()

script_dir = os.path.dirname(os.path.abspath(__file__))

bacaras_pragmatic_path = os.path.join(script_dir, 'bacaras_pragmatic.json')
bacaras_evolution_path = os.path.join(script_dir, 'bacaras_evolution.json')
bac_foot_evolution_path = os.path.join(script_dir, 'bac_foot_evolution.json')
stock_marcket_evolution_path = os.path.join(script_dir, 'stock_marcket_evolution.json')
roletas_evolution_path = os.path.join(script_dir, 'roletas_evolution.json')
roletas_pragmatic_path = os.path.join(script_dir, 'roletas_pragmatic.json')
supertrunfo_pragmatic_path = os.path.join(script_dir, 'supertrunfo_pragmatic.json')
megawill_pragmatic_path = os.path.join(script_dir, 'megawill_pragmatic.json')
dados_usuario_arquivo = os.path.join(script_dir, 'dados_usuario.json')

def carregar_dados_usuario():
    if os.path.exists(dados_usuario_arquivo):
        with open(dados_usuario_arquivo, 'r') as file:
            return json.load(file)
    return None

def salvar_dados_usuario(cpf, senha):
    dados = {
        "cpf": cpf,
        "senha": senha
    }
    with open(dados_usuario_arquivo, 'w') as file:
        json.dump(dados, file)

last_counts1 = {}
@sio.on("bacaras_pragmatic")
def handle_bacaras_pragmatic(data):
    try:
        try:
            with open(bacaras_pragmatic_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts1.get(key, None):
                    existing_data[key] = value
                    last_counts1[key] = value['count']
            else:
                existing_data[key] = value
                last_counts1[key] = value['count']

        with open(bacaras_pragmatic_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass

last_counts2 = {}
@sio.on("bacaras_evolution")
def handle_bacaras_evolution(data):
    try:
        try:
            with open(bacaras_evolution_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts2.get(key, None):
                    existing_data[key] = value
                    last_counts2[key] = value['count']
            else:
                existing_data[key] = value
                last_counts2[key] = value['count']

        with open(bacaras_evolution_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass

last_counts3 = {}
@sio.on("bac_foot_evolution")
def handle_bac_foot_evolution(data):
    try:
        try:
            with open(bac_foot_evolution_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts3.get(key, None):
                    existing_data[key] = value
                    last_counts3[key] = value['count']
            else:
                existing_data[key] = value
                last_counts3[key] = value['count']

        with open(bac_foot_evolution_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass

last_counts4 = {}
@sio.on("stock_marcket_evolution")
def handle_stock_marcket_evolution(data):
    try:
        try:
            with open(stock_marcket_evolution_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts4.get(key, None):
                    existing_data[key] = value
                    last_counts4[key] = value['count']
            else:
                existing_data[key] = value
                last_counts4[key] = value['count']

        with open(stock_marcket_evolution_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass

last_counts5 = {}
@sio.on("roletas_evolution")
def handle_roletas_evolution(data):
    try:
        try:
            with open(roletas_evolution_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts5.get(key, None):
                    existing_data[key] = value
                    last_counts5[key] = value['count']
            else:
                existing_data[key] = value
                last_counts5[key] = value['count']

        with open(roletas_evolution_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass

last_counts6 = {}
@sio.on("roletas_pragmatic")
def handle_roletas_pragmatic(data):
    try:
        try:
            with open(roletas_pragmatic_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts6.get(key, None):
                    existing_data[key] = value
                    last_counts6[key] = value['count']
            else:
                existing_data[key] = value
                last_counts6[key] = value['count']

        with open(roletas_pragmatic_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass

last_counts7 = {}
@sio.on("supertrunfo_pragmatic")
def handle_supertrunfo_pragmatic(data):
    try:
        try:
            with open(supertrunfo_pragmatic_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts7.get(key, None):
                    existing_data[key] = value
                    last_counts7[key] = value['count']
            else:
                existing_data[key] = value
                last_counts7[key] = value['count']

        with open(supertrunfo_pragmatic_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass

last_counts8 = {}
@sio.on("megawill_pragmatic")
def handle_megawill_pragmatic(data):
    try:
        try:
            with open(megawill_pragmatic_path, 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for key, value in data.items():
            if key in existing_data:
                if value['count'] != last_counts8.get(key, None):
                    existing_data[key] = value
                    last_counts8[key] = value['count']
            else:
                existing_data[key] = value
                last_counts8[key] = value['count']

        with open(megawill_pragmatic_path, 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        pass
        
@sio.on("autenticacao_sucesso")
def handle_autenticacao_sucesso(data):
    try:
        token = data['token']
        print("Autenticação bem-sucedida! API On")
        sio.emit('connect_token', {'token': token})
    except KeyError:
        pass

@sio.on("autenticacao_falha")
def handle_autenticacao_falha(data):
    print("Falha na autenticação:", data['message'])

def autenticar(cpf, senha):
    sio.emit("autenticar", {"cpf": cpf, "senha": senha})

if __name__ == "__main__":
    try:
        dados_usuario = carregar_dados_usuario()
        if dados_usuario:
            cpf = dados_usuario['cpf']
            senha = dados_usuario['senha']
            
        else:
            cpf = input("Digite o CPF: ").lstrip('0') 
            senha = input("Digite a senha: ")
            salvar_dados_usuario(cpf, senha)

        sio.connect("wss://apiafobada.com.br")  
        autenticar(cpf, senha)  
        sio.wait() 
        
    except Exception as e:
        print(f"Erro ao conectar: {e}")
