import json
import os
import sys
import socketio

sio = socketio.Client()

@sio.event
def connect():
    print("API Ligada")

@sio.event
def disconnect():
    print("API Desligada")
    sys.exit()
    
script_dir = os.path.dirname(os.path.abspath(__file__))

dados_usuario_arquivo = os.path.join(script_dir, 'dados_usuario.json')
def carregar_dados_usuario():
    if os.path.exists(dados_usuario_arquivo):
        with open(dados_usuario_arquivo, 'r') as file:
            return json.load(file)
    return None

def salvar_dados_usuario(cpf, senha):
    dados = {
        "cpf": cpf,
        "senha": senha
    }
    with open(dados_usuario_arquivo, 'w') as file:
        json.dump(dados, file)

script_dir = os.path.dirname(os.path.abspath(__file__))

json_files = {
    'bacaras': 'bacaras_pragmatic.json',
    'bacaras1': 'bacaras_evolution.json',
    'bacara2': 'bac_foot_evolution.json',
    'bacara3': 'stock_marcket_evolution.json',
    'bacara4': 'roletas_evolution.json',
    'bacara5': 'roletas_pragmatic.json',
    'bacara6': 'supertrunfo_pragmatic.json',
    'bacara7': 'megawill_pragmatic.json',
    'bacara8': 'super_sig_bo_pragmatic.json'
}

json_paths = {key: os.path.join(script_dir, f'{value}') for key, value in json_files.items()}

last_counts = {key: {} for key in json_files.keys()}

def save_data_to_json(key, data):
    try:
       
        try:
            with open(json_paths[key], 'r') as json_file:
                existing_data = json.load(json_file)
        except FileNotFoundError:
            existing_data = {}

        for item_key, value in data.items():
            if item_key in existing_data:
                if value['count'] != last_counts[key].get(item_key, None):
                    existing_data[item_key] = value
                    last_counts[key][item_key] = value['count']
            else:
                existing_data[item_key] = value
                last_counts[key][item_key] = value['count']

        with open(json_paths[key], 'w') as json_file:
            json.dump(existing_data, json_file, indent=4)

    except Exception as e:
        print(f"Erro ao salvar os dados para {key}: {e}")

@sio.on("bacaras")
def handle_bacaras(data):
    save_data_to_json('bacaras', data)

@sio.on("bacaras1")
def handle_bacaras1(data):
    save_data_to_json('bacaras1', data)

@sio.on("bacara2")
def handle_bacara2(data):
    save_data_to_json('bacara2', data)

@sio.on("bacara3")
def handle_bacara3(data):
    save_data_to_json('bacara3', data)

@sio.on("bacara4")
def handle_bacara4(data):
    save_data_to_json('bacara4', data)

@sio.on("bacara5")
def handle_bacara5(data):
    save_data_to_json('bacara5', data)

@sio.on("bacara6")
def handle_bacara6(data):
    save_data_to_json('bacara6', data)

@sio.on("bacara7")
def handle_bacara7(data):
    save_data_to_json('bacara7', data)

@sio.on("bacara8")
def handle_bacara8(data):
    save_data_to_json('bacara8', data)

@sio.on("autenticacao_sucesso")
def handle_autenticacao_sucesso(data):
    try:
        token = data['token']
        print("Autenticação bem-sucedida! API On")
        sio.emit('connect_token', {'token': token})
    except KeyError:
        pass

@sio.on("autenticacao_falha")
def handle_autenticacao_falha(data):
    print("Falha na autenticação:", data['message'])

def autenticar(cpf, senha):
    sio.emit("autenticar", {"cpf": cpf, "senha": senha})

if __name__ == "__main__":
    try:
        dados_usuario = carregar_dados_usuario()
        if dados_usuario:
            cpf = dados_usuario['cpf']
            senha = dados_usuario['senha']
        else:
            cpf = input("Digite o CPF: ").lstrip('0') 
            senha = input("Digite a senha: ")
            salvar_dados_usuario(cpf, senha)

        sio.connect("wss://apiafobada.com.br")  
        autenticar(cpf, senha)  
        sio.wait() 
        
    except Exception as e:
        print(f"Erro ao conectar: {e}")
