################ azul ##############
def aposta_azul(iframe):
    
    valor = """
    (() => {
        const botaoEntrar = document.querySelector("[data-role='bacbo-bet-spot-Player']");
        if (botaoEntrar) {
            botaoEntrar.click(); 
        } else {
            console.log("Botão não encontrado!");
        }
    })();
    """
    iframe.evaluate(valor)


################ vermelho ##############
def aposta_vermelho(iframe):
    
    valor = """
    (() => {
        const botaoEntrar = document.querySelector("[data-role='bacbo-bet-spot-Banker']");
        if (botaoEntrar) {
            botaoEntrar.click(); 
        } else {
            console.log("Botão não encontrado!");
        }
    })();
    """
    iframe.evaluate(valor)



############################################
################# Ficha 2.5 ################
############################################
def ficha_2_5(iframe):
  
  ficha_5 = '//*[@id="root"]/div/div/div[2]/div[2]/div/div[7]/div[3]/div/div/div[2]/div/div[1]' 
  
  iframe.click(ficha_5)


############################################
################# Ficha 5 ################
############################################
def ficha_5(iframe):
  
  ficha_5 = '//*[@id="root"]/div/div/div[2]/div[2]/div/div[7]/div[3]/div/div/div[2]/div/div[2]' 
  
  iframe.click(ficha_5)


############################################
################# Ficha 25 ################
############################################
def ficha_25(iframe):
  
  ficha_25 = f'//*[@id="root"]/div/div/div[2]/div[6]/div/div[4]/div/div[2]/div/div[2]'
 
  iframe.click(ficha_25)


################# CLICAR NO BOTAO DOBRAR ################
def dobrar(iframe):
  
  dobrar = '''//*[@id="root"]/div/div/div[2]/div[2]/div/div[7]/div[3]/div/div/div[3]/div/button'''
  
  iframe.click(dobrar)
