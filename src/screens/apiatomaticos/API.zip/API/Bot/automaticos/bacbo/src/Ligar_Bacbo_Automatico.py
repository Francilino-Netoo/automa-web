import csv
import os
import json
import re
import threading
import time
import json
import time
from flask import Flask
from flask_cors import CORS
import json
from playwright.sync_api import sync_playwright
from login import inatividade,login,atualizar
from ficha import aposta_azul, aposta_vermelho,ficha_2_5,ficha_5,ficha_25,dobrar

app = Flask(__name__)
CORS(app)  

def get_script_dir():
    return os.path.dirname(os.path.abspath(__file__))

def check_and_create_file(filename, initial_value=0):
    script_dir = get_script_dir() 
    file_path = os.path.join(script_dir, filename)  

    if not os.path.exists(file_path):  
        with open(file_path, "w") as file:
            file.write(str(initial_value)) 

def ler_json(nome_arquivo):
    try:
        with open(nome_arquivo, 'r') as arquivo:
            dados = json.load(arquivo)
        return dados
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError:
        return {}
    
def escrever_json(nome_arquivo, dados):
    with open(nome_arquivo, 'w') as arquivo:
        json.dump(dados, arquivo, indent=4)

def criar_arquivo_csv(nome_arquivo, comentario, dados_iniciais):
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(script_dir, nome_arquivo)

    if not os.path.exists(csv_path):
        print(f"Arquivo {csv_path} não encontrado, criando um novo arquivo...")
        with open(csv_path, mode='w', encoding='utf-8', newline='') as file:
           
            file.write(f"# {comentario}\n")
            
            writer = csv.writer(file, delimiter='=')
         
            for linha in dados_iniciais:
                writer.writerow(linha)

def carregar_estrategias():
    
    estrategias = {
        "bacbo": {}
    }

    arquivos = {
        "bacbo.csv": {
            "comentario": "Este arquivo contém estratégias de cores!\n# As estratégias são divididas entre (Estratégia=Entrata=Gale)\n# Exemplo de como você deve adicionar suas estratégias:\n# Se quer que entre na cor AZUL deve fazer assim VVVV=A=2\n# No exemplo acima se sair 4 vermelhos vai enviar a mensagem pedindo para entrar no azul e realizar 2 gales\n#",
            "dados_iniciais": [["VV", "V","1"], ["AV", "V","1"]]
        }
    }

    for nome_arquivo, conteudo in arquivos.items():
        criar_arquivo_csv(nome_arquivo, conteudo["comentario"], conteudo["dados_iniciais"])

    for nome_arquivo_base in estrategias:
        nome_arquivo = f"{nome_arquivo_base}.csv" 
        csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), nome_arquivo)
        try:
            with open(csv_path, mode='r', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter='=')
                for row in reader:
                    if not row or row[0].startswith('#'):
                        continue
                    if len(row) == 3: 
                        estrategias[nome_arquivo_base][row[0].strip()] = [row[1].strip(), row[2].strip()]

        except Exception as e:
            print(f"Ocorreu um erro ao carregar o arquivo {nome_arquivo}: {e}")
    
    return estrategias

def caminho_absoluto(nome_arquivo):
   
    script_dir = get_script_dir()
    return os.path.join(script_dir, nome_arquivo)

lista = []

color = None
total_gales_azul = None
total_gales_vermelho = None

gales = 0
apostar = 0
aposta = 0

apostar_azul = 0
apostar_vermelho = 0

libera_gales = 0

g_azul = None
g_verm = None
constante = 0


def carregar_lista_resultados(results_id, result_data):
    global total_gales_azul,total_gales_vermelho,libera_gales,color,apostar,apostar_azul,apostar_vermelho,gales,aposta,g_azul,g_verm,constante
    estrategias = carregar_estrategias()
    estrategias_cores = estrategias.get("bacbo", {})
    print(estrategias_cores)

    if 'results' in result_data:
        results = result_data['results'][0]

        if results == 'Player':
            color = 'A'
        elif results == 'Banker':
            color = 'V'
        elif results == 'Tie':
            color = 'E'

        if color:
            lista.append(color) 
            print(f"Lista atual: {lista}")

            resultados_string = ''.join(lista)
            print(f"Resultados em string: {resultados_string}")

            if apostar == 0:
                if resultados_string in estrategias_cores:
                    print({'Sinal encontrado': estrategias_cores[resultados_string][0]})
                    
                    if estrategias_cores[resultados_string][0] == 'A': # Primerira entrada
                        constante = 1
                        g_azul = 0 
                        g_verm = None
                        
                        total_gales_azul = int(estrategias_cores[resultados_string][1])
                        
                        apostar = 1
                        aposta = 'A'
                        
                        apostar_azul = 1
                        apostar_vermelho = 0
                        
                        libera_gales = 1 
                        
                        lista.clear()  
                        
                    elif estrategias_cores[resultados_string][0] == 'V':
                        constante = 1
                        g_azul = None
                        g_verm = 0
                        
                        total_gales_vermelho = int(estrategias_cores[resultados_string][1])
                         
                        apostar = 1
                        aposta = 'V'
                        apostar_azul = 0
                        apostar_vermelho = 1
                        libera_gales = 1
                        lista.clear()  
                        
                else:
                    
                    for estrategia in estrategias_cores:
                        if estrategia.startswith(resultados_string) and len(resultados_string) + 1 == len(estrategia):
                            print({'possivel_sinal_cores': estrategias_cores[estrategia][0]})
                            break

                    if not any(estrategia.startswith(resultados_string) for estrategia in estrategias_cores):
                        print("Nenhuma estratégia correspondente encontrada.")
                        
                        lista.clear()  
                    
            elif apostar == 1:
                
                if apostar_azul == 1:
                    
                    if resultados_string == aposta: # aposta = 'A'
                        print('Win no azul')
                        constante = 0
                        g_azul = None #vai voltar para o estado inicial
                        g_verm = None
                        gales = 0
                        apostar_azul = 0
                        libera_gales = 0
                        apostar = 0
                        lista.clear()
                     
                    elif resultados_string == 'E': #EMPATE
                        print('Win no empate')
                        constante = 0
                        g_azul = None
                        g_verm = None
                        gales = 0
                        apostar_azul = 0
                        libera_gales = 0
                        apostar = 0
                        lista.clear()
                        
                    else:
                        
                        gales += 1
                        
                        if gales > total_gales_azul: # vai da los pois o total de gales vai ser maior
                            print('Los no azul')
                            constante = 0
                            g_azul = None
                            g_verm = None
                            apostar = 0
                            gales = 0
                            apostar_vermelho = 0
                            libera_gales = 0
                            lista.clear()
                        
                        elif gales > 0 and gales <= total_gales_azul: # ENTRA NO GALE
                            if libera_gales == 1:
                                print('Entrou no gale azul')
                                constante = 1
                                g_azul += 1  #vai somar mais 1 se ele começou com 0 entao vai ser g_azul = 1 e constante = 1
                                g_verm = None  
                                lista.clear()  
                                
                            else:
                                libera_gales = 0 
                                
                elif apostar_vermelho == 1: # VAI ENTRAR AQUI
                    
                    if resultados_string == aposta:
                        print('Win no vermelho')
                        constante = 0
                        g_azul = None
                        g_verm = None
                        apostar_vermelho = 0
                        gales = 0
                        apostar_azul = 0
                        apostar = 0
                        libera_gales = 0
                        lista.clear()
                     
                    if resultados_string == 'E':
                        print('Win no empate')
                        constante = 0
                        g_azul = None
                        g_verm = None
                        apostar_vermelho = 0
                        gales = 0
                        apostar_azul = 0
                        libera_gales = 0
                        apostar = 0
                        lista.clear()
                        
                    else:
                        
                        gales += 1
                       
                        if gales > total_gales_vermelho:
                            print('Los no vermelho')
                            constante = 0
                            g_azul = None
                            g_verm = None
                            apostar = 0
                            gales = 0
                            apostar_vermelho = 0
                            libera_gales = 0
                            lista.clear()
                        
                        elif gales > 0 and gales <= total_gales_vermelho:
                            if libera_gales == 1:
                                
                                constante = 1
                                g_azul = None 
                                g_verm += 1
                                lista.clear()  
                                
                            else:
                                libera_gales = 0 

###########################################################

browser = None
context = None
def run(playwright):
    global g_azul, g_verm, perspective_container, constante
    global browser, context  
    
    if browser is None:
        chromium = playwright.chromium
        browser = chromium.launch(headless=False)
        context = browser.new_context(locale='en-US')

    page = context.new_page()

    try:
        
        login(page)
        
        page.goto("https://blaze.com/pt/games/bac-bo-ao-vivo")
        
        iframe_element = page.wait_for_selector('iframe', timeout=5000)
        iframe_src = iframe_element.get_attribute('src')
        if iframe_src:
            page.goto(iframe_src)  
        else:
            print("Nenhuma URL encontrada no iframe.")

        def get_iframe(page):
            try:
                iframe_element = page.wait_for_selector('iframe', timeout=5000)
                return iframe_element.content_frame()
            except Exception as e:
                print(f"Erro ao obter iframe: {e}")
                return None

        iframe = get_iframe(page)

        while True:
            try:
                
                recarga(iframe,playwright)
                
                while True:
                    try:
                         
                        if g_azul == 0 and constante == 1: # ja nao ta mais nessa condiçao 
                            
                            print('CONTAGEM DOS GALES AZUL', g_azul)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                                print("Entrando no Azul")
                                time.sleep(7)
                                
                                ficha_2_5(iframe)
                                aposta_azul(iframe)
                                constante = 0
                                    
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                            
                        elif g_azul == 1 and constante == 1: 
                            print('CONTAGEM DOS GALES AZUL', g_azul)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                                
                                time.sleep(7)
                                print("G1 Azul")
                                ficha_5(iframe)
                                aposta_azul(iframe)
                                
                                constante = 0
                                
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                            
                        elif g_azul == 2 and constante == 1:
                            print('CONTAGEM DOS GALES AZUL', g_azul)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                               
                                time.sleep(7)
                                print("G2 Azul")
                                aposta_azul(iframe)
                                dobrar(iframe)
                                constante = 0
                                
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                        
                        elif g_azul == 3 and constante == 1:
                            print('CONTAGEM DOS GALES AZUL', g_azul)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                               
                                time.sleep(7)
                                print("G2 Azul")
                                aposta_azul(iframe)
                                aposta_azul(iframe)
                                dobrar(iframe)
                                constante = 0
                                
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                        
                        elif g_azul == 4 and constante == 1: #NO CASO AQUI SERIA GALE 4
                            print('CONTAGEM DOS GALES AZUL', g_azul)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                               
                                time.sleep(7)
                                print("G2 Azul")
                                aposta_azul(iframe)
                                aposta_azul(iframe)
                                dobrar(iframe)
                                dobrar(iframe)
                                constante = 0
                                
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                        
                        
                        ##########################################
                        ##########################################
                        ##########################################
                        elif g_verm == 0 and constante == 1:
                            print('CONTAGEM DOS GALES VERMELHOS', g_verm)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                                
                                time.sleep(7)
                                print("Entrando no Vermelho")  
                                ficha_2_5(iframe)
                                aposta_vermelho(iframe)
                                constante = 0
                                
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                            
                        elif g_verm == 1 and constante == 1:
                            print('CONTAGEM DOS GALES VERMELHOS', g_verm)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                               
                                time.sleep(7)
                                print("G1 Vermelho")
                                ficha_5(iframe)
                                aposta_vermelho(iframe)
                                constante = 0
                                
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                            
                        elif g_verm == 2 and constante == 1:
                            print('CONTAGEM DOS GALES VERMELHOS', g_verm)
                            perspective_container = iframe.query_selector('div[class*="wrapper--81984"]')
                            if perspective_container:
                               
                                time.sleep(7)
                                
                                print("G2 Vermelho")
                                aposta_azul(iframe)
                                dobrar(iframe)
                                
                                constante = 0
                                
                            else:
                                print("Aguardando...")
                                time.sleep(1)
                                
                        
                            
                    except Exception as inner_e:
                        print(f'Erro ao tentar clicar: {inner_e}')
                        time.sleep(2)
                
            except Exception as e:
                
                time.sleep(5)

    except KeyboardInterrupt:
        print("PAROU.")

    finally:
        pass


                    
def load_prever_resultados(filename):
    return ler_json(filename)

def carregar_resultados(current_results, prever_resultados, game_id):
    if game_id in current_results:
        result_data = current_results[game_id]
        if game_id in prever_resultados:
            prever_resultados_hora = prever_resultados[game_id]
            if result_data['count'] != prever_resultados_hora['count']:
                carregar_lista_resultados(game_id, result_data)
                prever_resultados[game_id] = result_data
                
        else:
            carregar_lista_resultados(game_id, result_data)
            prever_resultados[game_id] = result_data
    else:
        pass
    return prever_resultados

def get_or_set_game_id():
    config_filename = os.path.join(get_script_dir(), "bac.json")
    config_data = ler_json(config_filename)
    
    if "game_id" in config_data:
        game_id = config_data["game_id"]
    else:
        game_id = input("Entre com seu GAME ID: ")
        config_data["game_id"] = game_id
        escrever_json(config_filename, config_data)
    
    return game_id

def main():
    filename = "./././API/bac_foot_evolution.json"
    prever_resultados = {}
    game_id = get_or_set_game_id()

    while True:
        current_results = load_prever_resultados(filename)
        prever_resultados = carregar_resultados(current_results, prever_resultados, game_id)
        time.sleep(2)

def get_script_dir():
    return os.path.dirname(os.path.abspath(__file__))

def check_and_create_file(filename, initial_value=0):
    script_dir = get_script_dir() 
    file_path = os.path.join(script_dir, script_dir, filename)

    if not os.path.exists(file_path):  
        with open(file_path, "w") as file:
            file.write(str(initial_value))
    return file_path



def recarga(iframe,playwright):
    
    try:
        inactivity_message = iframe.wait_for_selector('.wrapper--cc5ca')
        if inactivity_message:
            inner_text = inactivity_message.inner_text().strip()
            if "JOGO PAUSADO POR INATIVIDADE" in inner_text:
                inatividade(iframe)
                pass  
    except Exception as e:
        pass
    
    try:
        expired = iframe.wait_for_selector('.contentWrapper--46f24')
        if expired: 
            inner_text_expired = expired.inner_text().strip()
            if "SESSÃO EXPIRADA" in inner_text_expired:
                print("Sessao expirou...")
                run(playwright)
                pass 
             
    except Exception as e:
        pass
    
    try:
        recarregar = iframe.wait_for_selector('.rootContainer--308ad')
        if recarregar:
            inner_text_recarregar = recarregar.inner_text().strip()
            if "Recarregue a página para voltar ao jogo neste dispositivo" in inner_text_recarregar:
                print("recarregar pagina")
                atualizar(iframe)
                pass  
    except Exception as e:
        pass

def apostando():
    with sync_playwright() as playwright:
        run(playwright)

if __name__ == "__main__":

    thread_main = threading.Thread(target=main)
    thread_main.start()

    thread_main1 = threading.Thread(target=apostando)
    thread_main1.start()

    thread_main.join()  
    thread_main1.join() 
