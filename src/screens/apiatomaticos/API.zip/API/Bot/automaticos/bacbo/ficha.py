def ficha_5():
  
  ficha_5 = '//*[@id="root"]/div/div/div[2]/div[2]/div/div[7]/div[3]/div/div/div[2]/div/div[1]'
  
  return ficha_5

def ficha_10():
  
  ficha_10 = f'//*[@id="root"]/div/div/div[2]/div[6]/div/div[4]/div/div[2]/div/div[2]'
          
  return ficha_10