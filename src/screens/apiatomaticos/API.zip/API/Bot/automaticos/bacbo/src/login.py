import time

############# Login ##################
def login(page):
    
    email = "apiafobada@gmail.com"
    senha = "Acerola12345"
    
    page.goto("https://blaze.com/pt/games/category/live-casino?modal=auth&tab=login")
    page.wait_for_selector('input[name="username"]')
    page.fill('input[name="username"]', email)
    page.wait_for_selector('input[name="password"]')
    page.fill('input[name="password"]', senha)
    page.press('input[name="password"]', 'Enter')
    time.sleep(2)

############ inatividade ###############
def inatividade(iframe):
    
    button1 = '''//*[@id="root"]/div/div/div[2]/div[6]'''
    try:
        iframe.click(button1)
    except:
        pass

############ atualizar ###############
def atualizar(iframe):
    
    button1 = '''//*[@id="root"]/div/div/div[2]/div[6]/div/div/div/div[2]/div/div[2]/button'''
    try:
        iframe.click(button1)
    except:
        pass

