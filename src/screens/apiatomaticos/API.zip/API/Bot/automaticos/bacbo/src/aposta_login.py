import time

############# Login ##################
def login(page):
    
    email = "seu email"
    senha = "Sua senha"
    
    page.goto("https://blaze.com/pt/games/category/live-casino?modal=auth&tab=login")
    page.wait_for_selector('input[name="username"]')
    page.fill('input[name="username"]', email)
    page.wait_for_selector('input[name="password"]')
    page.fill('input[name="password"]', senha)
    page.press('input[name="password"]', 'Enter')
    time.sleep(2)


################ azul ##############
def aposta_azul():
    
    return """
    (() => {
        const botaoEntrar = document.querySelector("[data-role='bacbo-bet-spot-Player']");
        if (botaoEntrar) {
            botaoEntrar.click(); 
        } else {
            console.log("Botão não encontrado!");
        }
    })();
    """
    
################ vermelho ##############
def aposta_vermelho():
    return """
    (() => {
        const botaoEntrar = document.querySelector("[data-role="bacbo-bet-spot-Banker"]");
        if (botaoEntrar) {
            botaoEntrar.click(); 
        } else {
            console.log("Botão não encontrado!");
        }
    })();
    """
    
################# gales ################
def dobrar(iframe):
    button = '''//*[@id="root"]/div/div/div[2]/div[2]/div/div[7]/div[3]/div/div/div[3]/div/button'''
    iframe.click(button)

############ inatividade ###############
def inatividade(iframe):
    
    button1 = '''//*[@id="root"]/div/div/div[2]/div[6]'''
    try:
        iframe.click(button1)
    except:
        pass

############ atualizar ###############
def atualizar(iframe):
    
    button1 = '''//*[@id="root"]/div/div/div[2]/div[6]/div/div/div/div[2]/div/div[2]/button'''
    try:
        iframe.click(button1)
    except:
        pass
