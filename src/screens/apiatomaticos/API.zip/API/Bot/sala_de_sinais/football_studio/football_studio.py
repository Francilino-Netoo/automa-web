import csv
import os
import json
import time
import json
import time
from flask import Flask
from flask_cors import CORS
import json
import telebot

bot = telebot.TeleBot('7469246894:AAGKTQcfvL2kdAOdpK0d0GkczbJL6fWbD3M')
user_id = -1002454956621

app = Flask(__name__)
CORS(app)  
   
def tempo():
    time.sleep(10)

def get_script_dir():
    return os.path.dirname(os.path.abspath(__file__))

def check_and_create_file(filename, initial_value=0):
    script_dir = get_script_dir() 
    file_path = os.path.join(script_dir, filename)  

    if not os.path.exists(file_path):  
        with open(file_path, "w") as file:
            file.write(str(initial_value)) 

check_and_create_file("win.txt")
check_and_create_file("empate.txt")
check_and_create_file("los.txt")
check_and_create_file("consecutivas.txt")
         
def ler_json(nome_arquivo):
    try:
        with open(nome_arquivo, 'r') as arquivo:
            dados = json.load(arquivo)
        return dados
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError:
        return {}
    
def escrever_json(nome_arquivo, dados):
    with open(nome_arquivo, 'w') as arquivo:
        json.dump(dados, arquivo, indent=4)

def criar_arquivo_csv(nome_arquivo, comentario, dados_iniciais):
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(script_dir, nome_arquivo)

    if not os.path.exists(csv_path):
        print(f"Arquivo {csv_path} não encontrado, criando um novo arquivo...")
        with open(csv_path, mode='w', encoding='utf-8', newline='') as file:
           
            file.write(f"# {comentario}\n")
            
            writer = csv.writer(file, delimiter='=')
         
            for linha in dados_iniciais:
                writer.writerow(linha)

def carregar_estrategias():
    """
    Função para carregar estratégias de múltiplos arquivos CSV.
    """
    estrategias = {
        "foot": {}
    }

    arquivos = {
        "foot.csv": {
            "comentario": "Este arquivo contém estratégias de cores!\n# As estratégias são divididas entre (Estratégia=Entrata=Gale)\n# Exemplo de como você deve adicionar suas estratégias:\n# Se quer que entre na cor AZUL deve fazer assim VVVV=A=2\n# No exemplo acima se sair 4 vermelhos vai enviar a mensagem pedindo para entrar no azul e realizar 2 gales\n#",
            "dados_iniciais": [["VV", "V"], ["AV", "V"]]
        }
    }

    for nome_arquivo, conteudo in arquivos.items():
        criar_arquivo_csv(nome_arquivo, conteudo["comentario"], conteudo["dados_iniciais"])

    for nome_arquivo_base in estrategias:
        nome_arquivo = f"{nome_arquivo_base}.csv" 
        csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), nome_arquivo)
        try:
            with open(csv_path, mode='r', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter='=')
                for row in reader:
                    if not row or row[0].startswith('#'):
                        continue
                    if len(row) == 3: 
                        estrategias[nome_arquivo_base][row[0].strip()] = [row[1].strip(), row[2].strip()]


        except Exception as e:
            print(f"Ocorreu um erro ao carregar o arquivo {nome_arquivo}: {e}")
    
    return estrategias

def caminho_absoluto(nome_arquivo):
   
    script_dir = get_script_dir()
    return os.path.join(script_dir, nome_arquivo)

def conta_placar():
    global winn, empateo, losd, assertividade, consecutivas,consecutivas_file
    
    win_file = caminho_absoluto("win.txt")
    empate_file = caminho_absoluto("empate.txt")
    los_file = caminho_absoluto("los.txt")
    consecutivas_file = caminho_absoluto("consecutivas.txt")

    with open(win_file, "r+") as arquivo:
        gren = int(arquivo.read())

    with open(empate_file, "r+") as arquivo:
        branca = int(arquivo.read())

    with open(los_file, "r+") as arquivo:
        los = int(arquivo.read())
    
    with open(consecutivas_file, "r+") as arquivo:
        consec = int(arquivo.read())

    g = winn + empateo + branca + gren
    t = winn + empateo + losd + los + gren + branca
    asserti = (g / t) * 100
    asserti = f'{asserti:.2f}'

    msg = f'''✅ <i>{winn + gren}</i>\n🟤 <i>{branca+empateo}</i>\n❌ <i>{los+losd}</i>\n\n<b>📈 Consecutivas 📈</b> <b>=</b> {consecutivas+consec}\n\n<i>🎯 Assertividade 🎯</i> <b>=</b> {asserti}%'''
    bot.send_message(user_id, msg, parse_mode='HTML')

    valor = gren + winn
    valor2 = branca + empateo
    valor3 = los + losd
    valor4 = consecutivas + consec

    with open(win_file, "w+") as arquivo:
        arquivo.write(str(valor))

    with open(empate_file, "w+") as arquivo:
        arquivo.write(str(valor2))

    with open(los_file, "w+") as arquivo:
        arquivo.write(str(valor3))

    with open(consecutivas_file, "w+") as arquivo:
        arquivo.write(str(valor4))

    winn = 0
    empateo = 0
    losd = 0
    consecutivas = 0

possivel_sinal =f'''<b>🤓💻❗❗❗ATENÇÃO❗❗❗💻🤓</b>\n\n<i>🤑ANALISANDO POSSIVÉL SINAL🤑</i>'''

############ azul #################
def entrar_azul(total_gales_azul):
    azul_azul = f'''<b>🤖 ROBÔ FOOTBALL STUDIO 🤖</b>\n<i>➡ Apostar no</i> <b>AZUL</b> 🔵\n<i>➡ Proteger</i> <b>EMPATE 🟤</b>\n<i>➡ Realizar</i> <b>{total_gales_azul}</b> <i>GALES</i>\n<b>➡ <a href='seu link'>♠️ Football Studio ♦️</a></b>'''
    return azul_azul

def win_azul():
  bot.edit_message_text(chat_id=user_id,text="<b>🤖 ROBÔ FOOTBALL STUDIO 🤖</b>\n<i>🟩 APOSTAR NO AZUL 🔵</i>\n<i>🟩 PROTEGER EMPATE 🟤</i>\n<b>🟩 Win 🟩</b>",message_id=int(azul25), parse_mode='HTML',disable_web_page_preview=True)

def win_azul_empate():
  bot.edit_message_text(chat_id=user_id,text="<b>🤖 ROBÔ FOOTBALL STUDIO 🤖</b>\n<i>🟩 APOSTAR NO AZUL 🔵</i>\n<i>🟩 PROTEGER EMPATE 🟤</i>\n<b>🟩 Win no Empate 🟩</b>",message_id=int(azul25), parse_mode='HTML',disable_web_page_preview=True)

def los_azul():
  bot.edit_message_text(chat_id=user_id,text="<b><a href='https://instagram.com/programador_afobado?igshid=ZDdkNTZiNTM='>🤖 ROBÔ FOOTBALL STUDIO 🤖</a></b>\n<i>🟥 APOSTAR NO AZUL 🔵</i>\n<i>🟥 PROTEGER EMPATE 🟤</i>\n<b>🟥 Los 🟥</b>",message_id=int(azul25), parse_mode='HTML',disable_web_page_preview=True)


############ vermelho ####################

def entra_vermelho(total_gales_vermelho):
    vermelho_vermelho = f'''<b>🤖 ROBÔ FOOTBALL STUDIO 🤖</b>\n<i>➡ Apostar no</i> <b>VERMELHO</b> 🔴\n<i>➡ Proteger</i> <b>EMPATE 🟤</b>\n<i>➡ Realizar</i> <b>{total_gales_vermelho}</b> <i>GALES</i>\n<b>➡ <a href='seu link'>♠️ Football Studio ♦️</a></b>'''
    return vermelho_vermelho

def win_vermelho():
  bot.edit_message_text(chat_id=user_id,text="<b>🤖 ROBÔ FOOTBALL STUDIO 🤖</b>\n<i>🟩 APOSTAR NO VERMELHO 🔴</i>\n<i>🟩 PROTEGER EMPATE 🟤</i>\n<b>🟩 Win 🟩</b>",message_id=int(vermelho25), parse_mode='HTML',disable_web_page_preview=True)

def win_vermelho_empate():
  bot.edit_message_text(chat_id=user_id,text="<b>🤖 ROBÔ FOOTBALL STUDIO 🤖</b>\n<i>🟤 APOSTAR NO VERMELHO 🔴</i>\n<i>🟩 PROTEGER EMPATE 🟤</i>\n<b>🟩 Win no Empate 🟩</b>",message_id=int(vermelho25), parse_mode='HTML',disable_web_page_preview=True)


def los_vermelho():
  bot.edit_message_text(chat_id=user_id,text="<b>🤖 ROBÔ FOOTBALL STUDIO 🤖</b>\n<i>🟥 APOSTAR NO VERMELHO 🔴</i>\n<i>🟥 PROTEGER EMPATE 🟤</i>\n<b>🟥 Los 🟥</b>",message_id=int(vermelho25), parse_mode='HTML',disable_web_page_preview=True)


lista = []
color = None

total_gales_azul = None
total_gales_vermelho = None

gales = 0

apostar = 0
aposta = 0
apostar_azul = 0
apostar_vermelho = 0

winn = 0
empateo = 0
losd = 0
assertividade = 0
contador = 0
consecutivas = 0
message_id = None
message_id5 = None
libera_gales = 0

def carregar_lista_resultados(results_id, result_data):
    global total_gales_azul,total_gales_vermelho,libera_gales,color,consecutivas_file, azul25,possivel_sinal, message_id,vermelho25,apostar,apostar_azul,apostar_vermelho,gales,aposta,winn,empateo,losd,assertividade,consecutivas,message_id5,consec
    estrategias = carregar_estrategias()
    estrategias_cores = estrategias.get("foot", {})
    print(estrategias_cores)

    if 'results' in result_data:
        results = result_data['results'][0]

        if results == 'R':
            color = 'A'
        elif results == 'L':
            color = 'V'
        elif results == 'Tie':
            color = 'E'

        if color:
            lista.append(color) 
            print(f"Lista atual: {lista}")

            resultados_string = ''.join(lista)
            print(f"Resultados em string: {resultados_string}")

            if apostar == 0:
                if resultados_string in estrategias_cores:
                    print({'sinal encontrado': estrategias_cores[resultados_string][0]})
                    
                    if estrategias_cores[resultados_string][0] == 'A':
                        try:
                            bot.delete_message(user_id, message_id5, timeout=8000)
                        except Exception as e:
                            print(f"Erro ao tentar deletar a mensagem: {e}")
                        total_gales_azul = int(estrategias_cores[resultados_string][1])
                        apostar = 1
                        aposta = 'A'
                        apostar_azul = 1
                        apostar_vermelho = 0
                        libera_gales = 1 
                        lista.clear()  
                        azul1 = bot.send_message(user_id, entrar_azul(total_gales_azul), parse_mode='HTML',disable_web_page_preview=True)  
                        azul25 = azul1.message_id 
                        
                    elif estrategias_cores[resultados_string][0] == 'V':
                        try:
                            bot.delete_message(user_id, message_id5, timeout=8000)
                        except Exception as e:
                            print(f"Erro ao tentar deletar a mensagem: {e}")
                        total_gales_vermelho = int(estrategias_cores[resultados_string][1]) 
                        apostar = 1
                        aposta = 'V'
                        apostar_azul = 0
                        apostar_vermelho = 1
                        libera_gales = 1
                        lista.clear()  
                        vermelho1 = bot.send_message(user_id, entra_vermelho(total_gales_vermelho), parse_mode='HTML',disable_web_page_preview=True) 
                        vermelho25 = vermelho1.message_id
                        
                else:
                    
                    for estrategia in estrategias_cores:
                        if estrategia.startswith(resultados_string) and len(resultados_string) + 1 == len(estrategia):
                            print({'possivel_sinal_cores': estrategias_cores[estrategia][0]})
                            
                            message = bot.send_message(user_id, possivel_sinal, parse_mode='HTML')
                            message_id5 = message.message_id 
                            break

                    if not any(estrategia.startswith(resultados_string) for estrategia in estrategias_cores):
                        print("Nenhuma estratégia correspondente encontrada. Limpando a lista_cores.")
                        try:
                            bot.delete_message(user_id, message_id5, timeout=8000)
                            
                        except Exception as e:
                            print(f"Erro ao tentar deletar a mensagem: {e}")  
                        lista.clear()  
                    
            elif apostar == 1:
                
                if apostar_azul == 1:
                    
                    if resultados_string == aposta:
                        winn = 1
                        consecutivas += 1
                        gales = 0
                        apostar_azul = 0
                        libera_gales = 0
                        apostar = 0
                        lista.clear()
                        win_azul()
                        azul25 = None
                        conta_placar()
                    
                    elif resultados_string == 'E':
                        winn = 1
                        consecutivas += 1
                        empateo = 1
                        gales = 0
                        apostar_azul = 0
                        libera_gales = 0
                        apostar = 0
                        lista.clear()
                        win_azul_empate()
                        azul25 = None
                        conta_placar()
                        
                    else:
                        
                        gales += 1
                        
                        
                        
                        if gales > total_gales_azul:
                            apostar = 0
                            gales = 0
                            apostar_vermelho = 0
                            consec = 0
                            consecutivas = 0
                            libera_gales = 0
                            if consec == 0:
                                with open(consecutivas_file, "w+") as arquivo:
                                    arquivo.write(str(consec))

                            losd = 1
                            lista.clear()
                            los_azul()
                            azul25 = None
                            conta_placar()
                        
                        
                            
                        elif gales <= total_gales_azul:
                            
                            if libera_gales == 1:
                                msg = f'''<b>❗❗❗ {gales}º GALE ❗❗❗</b>'''
                                message_ids = bot.send_message(user_id, msg,parse_mode='HTML').message_id
                                tempo()
                                bot.delete_message(user_id, message_ids, timeout=8000)
                                lista.clear()

                            else:
                                libera_gales = 0
                            
                elif apostar_vermelho == 1:
                    
                    if resultados_string == aposta:
                        apostar_vermelho = 0
                        gales = 0
                        apostar_azul = 0
                        apostar = 0
                        winn = 1
                        libera_gales = 0
                        consecutivas += 1
                        lista.clear()
                        win_vermelho()
                        vermelho25 = None
                        conta_placar()
                      
                    if resultados_string == 'E':
                        winn = 1
                        consecutivas += 1
                        empateo = 1
                        apostar_vermelho = 0
                        gales = 0
                        apostar_azul = 0
                        libera_gales = 0
                        apostar = 0
                        lista.clear()
                        win_vermelho_empate()
                        vermelho25 = None
                        conta_placar()
                        
                    else:
                        
                        gales += 1
                            
                        if gales > total_gales_vermelho:
                            apostar = 0
                            gales = 0
                            apostar_vermelho = 0
                            consec = 0
                            consecutivas = 0
                            libera_gales = 0
                            if consec == 0:
                                with open(consecutivas_file, "w+") as arquivo:
                                    arquivo.write(str(consec))

                            losd = 1
                            lista.clear()
                            los_vermelho()
                            vermelho25 = None
                            conta_placar()
                          
                        elif gales <= total_gales_vermelho:
                            if libera_gales == 1:
                                msg = f'''<b>❗❗❗ {gales}º GALE ❗❗❗</b>'''
                                message_ids = bot.send_message(user_id, msg,parse_mode='HTML').message_id
                                tempo()
                                bot.delete_message(user_id, message_ids, timeout=8000)
                                lista.clear()
                            else:
                                libera_gales = 0
                       
def load_prever_resultados(filename):
    return ler_json(filename)

conta = 0
def carregar_resultados(current_results, prever_resultados, game_id):
    global conta
    if game_id in current_results:
        result_data = current_results[game_id]
        if game_id in prever_resultados:
            prever_resultados_hora = prever_resultados[game_id]
            if result_data['count'] != prever_resultados_hora['count']:
                carregar_lista_resultados(game_id, result_data)
                prever_resultados[game_id] = result_data
                
        else:
            carregar_lista_resultados(game_id, result_data)
            prever_resultados[game_id] = result_data
    else:
        pass
    return prever_resultados

def get_or_set_game_id():
    config_filename = os.path.join(get_script_dir(), "foot.json")
    config_data = ler_json(config_filename)
    
    if "game_id" in config_data:
        game_id = config_data["game_id"]
    else:
        game_id = input("Entre com seu GAME ID: ")
        config_data["game_id"] = game_id
        escrever_json(config_filename, config_data)
    
    return game_id

def main():
    filename = "./././API/bac_foot_evolution.json"
    prever_resultados = {}
    game_id = get_or_set_game_id()

    while True:
        current_results = load_prever_resultados(filename)
        prever_resultados = carregar_resultados(current_results, prever_resultados, game_id)
        time.sleep(2)

if __name__ == "__main__":
    main()
