import os
import subprocess
import time

scripts = ["./API/API.py"]

processes = {}

def start_process(script):
    python_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.venv', 'Scripts', 'python.exe')
    return subprocess.Popen([python_path, script])

for script in scripts:
    processes[script] = start_process(script)

while True:
    for script, process in processes.items():
        if process.poll() is not None:
            print(f"{script} parou. Reiniciando...")
            processes[script] = start_process(script)

    time.sleep(5)